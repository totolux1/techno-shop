
const express = require('express');
const router = express.Router();

const productos = [
  { id: 1, nombre: "Auriculares Bluetooth", precio: 29.99 },
  { id: 2, nombre: "Smartphone X200", precio: 599.99 }
];

router.get('/', (req, res) => {
  res.json(productos);
});

module.exports = router;
